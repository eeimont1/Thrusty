## Why

What problem does this solve?

## Change

What behavior changes?

## Verification

List checks actually run, hardware used if relevant, and remaining limitations.
